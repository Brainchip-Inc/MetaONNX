"""
Global onnx2akida workflow
==========================

"""
